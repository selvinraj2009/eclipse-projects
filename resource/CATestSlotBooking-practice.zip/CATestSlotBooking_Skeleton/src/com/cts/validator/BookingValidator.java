package com.cts.validator;

import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cts.vo.BookingSlotVO;

@Component
public class BookingValidator implements Validator {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return BookingSlotVO.class.isAssignableFrom(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.validation.Validator#validate(java.lang.Object,
	 * org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object arg0, Errors errors) {
		// TODO Auto-generated method stub
		BookingSlotVO bookingSlotVO = (BookingSlotVO) arg0;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "employeeId", "required.employeeId",
				"Employee Id is required!");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "employeeName", "required.employeeName",
				"Employee Name is required!");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "required.email", "Email is required!");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phone", "required.phone", "Phone No is required!");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "accountName", "required.accountName",
				"Account Name is required!");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "assessmentName", "required.assessmentName",
				"Assessment Name is required!");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "level", "required.level", "Level is required!");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dateOfAssessment", "required.dateOfAssessment",
				"Date of Assessment (dd-MMM-yyyy)! is Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "slot", "required.slot", "Slot is required!");

		if ((null != bookingSlotVO.getEmployeeId() && !bookingSlotVO.getEmployeeId().isEmpty())) {
			if (!bookingSlotVO.getEmployeeId().matches("\\d{6}")) {
				errors.rejectValue("employeeId", "invalid.employeeId");
			}

		}

		if ((null != bookingSlotVO.getEmployeeName() && !bookingSlotVO.getEmployeeName().isEmpty())) {
			if (!bookingSlotVO.getEmployeeName().matches("^[a-zA-Z\\s]{2,30}$")) {
				errors.rejectValue("employeeName", "invalid.employeeName");
			}
		}

		if ((null != bookingSlotVO.getEmail() && !bookingSlotVO.getEmail().isEmpty())) {
			if (!bookingSlotVO.getEmail().matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
				errors.rejectValue("email", "invalid.email");
			}
		}

		if ((null != bookingSlotVO.getDateOfAssessment())) {
			if (new Date().after((Date) bookingSlotVO.getDateOfAssessment())) {
				errors.rejectValue("dateOfAssessment", "before.dateOfAssessment");
			}
		}

	}

}