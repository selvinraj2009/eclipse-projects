package com.cts.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.validator.BookingValidator;
import com.cts.vo.BookingSlotVO;

@Controller
public class BookingSlotController {

	@Autowired
	BookingValidator bookingValidator;

	private static final Logger LOGGER = LoggerFactory.getLogger(BookingSlotController.class);

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		dataBinder.registerCustomEditor(Date.class, new CustomDateEditor(simpleDateFormat, true));
		dataBinder.setValidator(bookingValidator);
	}

	@RequestMapping(value = "/bookSlot", method = RequestMethod.GET)
	public String bookSlot(ModelMap model) {

		model.addAttribute("bookSlotVO", new BookingSlotVO());
		LOGGER.info("Inside bookSlot method.");

		return "booking";
	}

	@RequestMapping(value = "/confirmBooking", method = RequestMethod.POST)
	public String confirmBookingDetails(@Valid @ModelAttribute("bookSlotVO") BookingSlotVO bookSlotVO,
			BindingResult bindingResult, ModelMap model) {

		if (bindingResult.hasErrors()) {
			LOGGER.info("Has errors returning to booking");
			return "booking";
		} else {
			LOGGER.info("validation success");
			return "bookingSuccess";
		}

	}

	@ModelAttribute("assessmentList")
	public Map<String, String> populateAssessmentList() {

		// Data referencing for java skills list box
		Map<String, String> assesmentList = new LinkedHashMap<String, String>();
		assesmentList.put("Spring 4.x Level1", "Spring 4.x CA Enablement Level1");
		assesmentList.put("Spring 4.x Level2", "Spring 4.x CA Enablement Level2");
		assesmentList.put("Spring 4.x Level3", "Spring 4.x CA Enablement Level3");
		assesmentList.put("Struts 2.x Level1", "Struts 2.x CA Enablement Level1");
		assesmentList.put("Struts 2.x Level2", "Struts 2.x CA Enablement Level2");
		assesmentList.put("Struts 2.x Level3", "Struts 2.x CA Enablement Level3");
		assesmentList.put("Hibernate 3.x Level1", "Hibernate 3.x CA Enablement Level1");
		assesmentList.put("Hibernate 3.x Level2", "Hibernate 3.x CA Enablement Level2");
		assesmentList.put("Hibernate 3.x Level3", "Hibernate 3.x CA Enablement Level3");
		assesmentList.put("JSF 1.x Level1", "JSF 1.x CA Enablement Level1");
		assesmentList.put("JSF 1.x Level2", "JSF 1.x CA Enablement Level2");
		assesmentList.put("JSF 1.x Level3", "JSF 1.x CA Enablement Level3");
		assesmentList.put("Core Java Level1", "Core Java CA Enablement Level1");
		assesmentList.put("Core Java Level2", "Core Java CA Enablement Level2");
		assesmentList.put("Core Java Level3", "Core Java CA Enablement Level3");
		assesmentList.put("Spring 4 MVC Level1", "Spring 4 MVC CA Enablement Level1");
		assesmentList.put("Spring 4 MVC Level2", "Spring 4 MVC CA Enablement Level2");
		assesmentList.put("Spring 4 MVC Level3", "Spring 4 MVC CA Enablement Level3");

		return assesmentList;
	}

	@ModelAttribute("levelList")
	public Map<String, String> populateLevelList() {

		// Data referencing for java skills list box
		Map<String, String> levelList = new LinkedHashMap<String, String>();
		levelList.put("Level1", "Level1");
		levelList.put("Level2", "Level2");
		levelList.put("Level3", "Level3");

		return levelList;
	}

	@ModelAttribute("slotList")
	public Map<String, String> populatetimeSlotList() {

		// Data referencing for java skills list box
		Map<String, String> slotList = new LinkedHashMap<String, String>();
		slotList.put("10:00 AM", "10:00 AM");
		slotList.put("12:00 PM", "12:00 PM");
		slotList.put("02:00 PM", "02:00 PM");
		slotList.put("04:00 PM", "04:00 PM");
		slotList.put("06:00 PM", "06:00 PM");

		return slotList;
	}
}