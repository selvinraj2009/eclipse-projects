package com.cognizant.bookmyseat.exception;

public class BookMySeatException extends Exception {
	public BookMySeatException(String message) {
		super(message);
	}

	public BookMySeatException(Throwable throwable) {
		super(throwable);
	}

	public BookMySeatException(String message, Throwable throwable) {
		super(message, throwable);
	}

}
