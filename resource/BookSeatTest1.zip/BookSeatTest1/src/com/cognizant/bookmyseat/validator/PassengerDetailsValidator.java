package com.cognizant.bookmyseat.validator;

import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.cognizant.bookmyseat.ticket.vo.PassengerDetailsVO;

@Component
public class PassengerDetailsValidator  implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		return PassengerDetailsVO.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object object, Errors errors) {
		// TODO Auto-generated method stub
		
		PassengerDetailsVO passengerDetailsVO = (PassengerDetailsVO)object;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "error.required", new Object[] {"Passenger Name"});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phoneNumber", "error.required", new Object[] {"Phone Number"});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "journeyDate", "error.required", new Object[] {"Journey Date"});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gender", "error.required", new Object[] {"Gender"});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cardNumber", "error.required", new Object[] {"Card Number"});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pin", "error.required", new Object[] {"Pin is required"});
		
		
		if(!passengerDetailsVO.getIsAgreed()) {
			errors.rejectValue("isAgreed", "error.required", new Object[] {"Agree"},null);
		}
		
		if(null!=passengerDetailsVO.getJourneyDate() && new Date().after((Date)passengerDetailsVO.getJourneyDate())) {
			errors.rejectValue("journeyDate", "invalid.doj");
		}
		
		if(!String.valueOf(passengerDetailsVO.getPhoneNumber()).matches("\\d{10}")) {
			errors.rejectValue("phoneNumber", "phone.error");
		}
		
	}

	
}
