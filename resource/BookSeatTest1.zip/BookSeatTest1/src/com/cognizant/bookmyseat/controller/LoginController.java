package com.cognizant.bookmyseat.controller;

import java.util.Locale;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.bookmyseat.login.vo.UserDetailsVO;

@Controller
public class LoginController {
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	HttpSession httpSession;
	
	@RequestMapping(method=RequestMethod.GET, value="gotoLogin")
	public ModelAndView goToLogin(Locale locale) {
		
		ModelAndView modelView = new ModelAndView();
		if((null != httpSession.getAttribute("sessionTimeOut")) && Boolean.valueOf(String.valueOf((httpSession.getAttribute("sessionTimeOut"))))) {
			modelView.getModelMap().addAttribute("loginError",messageSource.getMessage("login.timeout", new Object[] {}, locale));
		}
		modelView.getModelMap().addAttribute("user",new UserDetailsVO());
		modelView.setViewName("login");
		
		
		
		return modelView;
	}

	// Add appropriate annotations and code wherever required

	@RequestMapping(method=RequestMethod.POST, value="submitLogin")
	public String submitLogin(@ModelAttribute("user") UserDetailsVO user,@CookieValue(value="name", required=false) Locale locale, Model model){
	
		if((user.getUsername() !=null && !user.getUsername().isEmpty()) && (user.getPassword() !=null && !user.getPassword().isEmpty()) && user.getUsername().equals(user.getPassword()) ) {
			return"home";
		}else {
			model.addAttribute("loginError", messageSource.getMessage("login.invalid",new Object[] {},locale));
			return "login";
		}
	}

}
