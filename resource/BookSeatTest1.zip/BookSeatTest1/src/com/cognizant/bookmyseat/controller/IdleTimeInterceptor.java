package com.cognizant.bookmyseat.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.cognizant.bookmyseat.exception.BookMySeatException;

public class IdleTimeInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	HttpSession session;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws BookMySeatException {
		
		session.setMaxInactiveInterval(10);
		if (session.isNew()) {
			System.out.println("Logging out, due to inactive session");
			try {
				session.setAttribute("sessionTimeOut", true);
				response.sendRedirect("gotoLogin");

				return false;
			} catch (IOException e) {
				throw new BookMySeatException("IOException is thrown");
			}
		}

		System.out.println("Exiting post handle preHandle..." + request.getRequestURI());
		return true;
	}
}
