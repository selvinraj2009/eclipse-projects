package com.cognizant.bookmyseat.ticket.vo;

import java.util.Date;

public class PassengerDetailsVO {
	
	private String name;
	private long phoneNumber;
	private String source;
	private String destination;
	private Date journeyDate;
	private String gender;
	private long cardNumber;
	private int pin;
	private boolean isAgreed;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	
	public Date getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}

	public boolean getIsAgreed() {
		return isAgreed;
	}

	public void setIsAgreed(boolean isAgreed) {
		this.isAgreed = isAgreed;
	}
}
