package com.cognizant.bookmyseat.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class IdleTimeInterceptorMine extends HandlerInterceptorAdapter {

	@Autowired
	HttpSession session;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object obj) throws IOException {
		boolean flag = false;
		if (request.getRequestURI().contains("KKK") && session.isNew()) {
			flag = true;
			session.setAttribute("timeout", true);
			response.sendRedirect("GOTOLOGIN");
		}
		return flag;
	}
}