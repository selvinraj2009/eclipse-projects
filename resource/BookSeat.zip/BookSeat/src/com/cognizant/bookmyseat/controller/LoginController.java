package com.cognizant.bookmyseat.controller;

import java.util.Locale;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.bookmyseat.login.vo.UserDetailsVO;

@Controller
public class LoginController {

	@Autowired
	private MessageSource messageSource;
	@Autowired
	private HttpSession session;
	@RequestMapping(method = RequestMethod.GET, value = "goToLogin")
	public ModelAndView goToLogin(Locale locale) {

		ModelAndView model = new ModelAndView();
		UserDetailsVO userDetailsVO = new UserDetailsVO();

		model.getModelMap().addAttribute("userDetailsVO", userDetailsVO);
		model.setViewName("login");

		String erroMessage = null;

		if (session.getAttribute("timeout") != null) {
			erroMessage = messageSource.getMessage("login.timeout", new Object[] {}, locale);
			model.getModelMap().addAttribute("erroMessage", erroMessage);
		}

		return model;
	}

	// Add appropriate annotations and code wherever required

	@RequestMapping(method = RequestMethod.POST, value = "submitLogin")
	public String submitLogin(UserDetailsVO user, Model model,
			@CookieValue(value = "name", required = false) String name, Locale locale) {

		// Implement code here
		String erroMessage = null;

		if (user.getUserName() != null && !("".equals(user.getUserName())) && user.getPassword() != null
				&& !("".equals(user.getPassword())) && user.getUserName().equals(user.getPassword())) {
			return "home";
		} else {
			erroMessage = messageSource.getMessage("login.invalid", new Object[] {}, locale);
			model.addAttribute("erroMessage", erroMessage);
			return "login";
		}
	}

}
