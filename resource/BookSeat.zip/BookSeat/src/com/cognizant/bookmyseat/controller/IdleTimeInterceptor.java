package com.cognizant.bookmyseat.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.cognizant.bookmyseat.exception.BookMySeatException;

public class IdleTimeInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	private HttpSession session;
	@Autowired
	MessageSource mess;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws BookMySeatException {
		Integer.parseInt(mess.getMessage("idleTime", null, null));
		session.setMaxInactiveInterval(3 * 1000);
		if ((request.getRequestURI().contains("bookTicket") || request.getRequestURI().contains("submitBook"))
				&& session.isNew()) {
			System.out.println("Logging out, due to inactive session");
			try {
				session.setAttribute("timeout", true);
				response.sendRedirect("goToLogin");

				return false;
			} catch (IOException e) {
				throw new BookMySeatException("IOException is thrown");
			}
		}

		System.out.println("Exiting post handle preHandle..." + request.getRequestURI());
		return true;
	}
}
