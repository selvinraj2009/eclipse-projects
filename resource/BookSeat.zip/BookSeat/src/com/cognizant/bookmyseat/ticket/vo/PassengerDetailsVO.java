package com.cognizant.bookmyseat.ticket.vo;

import java.util.Date;

public class PassengerDetailsVO {
	
	private String name;
	
	private long phoneNumber;
	
	private Date doj;
	
	private String source;
	
	private String destination;
	
	private String gender;

	private long cardNumber;

	private int pinNumber;
	
	private boolean isAgreed;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public boolean getIsAgreed() {
		return isAgreed;
	}

	public void setIsAgreed(boolean isAgreed) {
		this.isAgreed = isAgreed;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PassengerDetailsVO [name=");
		builder.append(name);
		builder.append(", phoneNumber=");
		builder.append(phoneNumber);
		builder.append(", doj=");
		builder.append(doj);
		builder.append(", source=");
		builder.append(source);
		builder.append(", destination=");
		builder.append(destination);
		builder.append(", gender=");
		builder.append(gender);
		builder.append(", cardNumber=");
		builder.append(cardNumber);
		builder.append(", pinNumber=");
		builder.append(pinNumber);
		builder.append(", isAgreed=");
		builder.append(isAgreed);
		builder.append("]");
		return builder.toString();
	}

}
