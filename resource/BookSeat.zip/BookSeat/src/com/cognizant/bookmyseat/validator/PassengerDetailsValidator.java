package com.cognizant.bookmyseat.validator;

import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.cognizant.bookmyseat.ticket.vo.PassengerDetailsVO;

@Component
public class PassengerDetailsValidator  implements Validator{

	
	@Override
	public boolean supports(Class commandClass) {
	return PassengerDetailsVO.class.isAssignableFrom(commandClass);
	}

	@Override
	public void validate(Object commandObject, Errors errors) {
		PassengerDetailsVO passengerDetailsVO = (PassengerDetailsVO) commandObject;
		//Add validation code here
		
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "error.required", new Object[] { "Passenger Name" });
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phoneNumber", "error.required", new Object[] {"Phone Number"});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "doj", "error.required", new Object[] {"Date Of Joining"});
		ValidationUtils.rejectIfEmpty(errors, "gender", "error.required", new Object[] {"Gender"});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cardNumber", "error.required", new Object[] {"Card Number"});
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pinNumber", "error.required", new Object[] {"Pin Number"});
		
		if(passengerDetailsVO.getDoj()!=null)
		{
			Date doj = (Date)passengerDetailsVO.getDoj();
			Date currentDate = new Date();
			
			if(doj.before(currentDate))
			{
				errors.rejectValue("doj", "invalid.doj");
			}
		}
		if(String.valueOf(passengerDetailsVO.getPhoneNumber())!=null && !("".equals(String.valueOf(passengerDetailsVO.getPhoneNumber()))))
		{
			if(!(String.valueOf(passengerDetailsVO.getPhoneNumber()).matches("\\d{10}")))
			{
				errors.rejectValue("phoneNumber", "typeMismatch.int");
			}
		}
		if(!passengerDetailsVO.getIsAgreed())
		{
			errors.rejectValue("isAgreed", "error.required", new Object[]{"Agree"}, null);
		}
	}

}
