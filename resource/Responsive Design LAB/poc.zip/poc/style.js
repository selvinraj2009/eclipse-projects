$(document).ready(function(){
	$("#insurance").load("insurance.html", function(){
		$("#insuranceOpt").on("change", function(){
			$("#firstRow").removeClass("hide");			
		});
		
		function populateSelectBox(geturl, ele){
			console.log(geturl);
			console.log(ele);
			$.ajax({
				type:"post",
				dataType:"json",
				url:geturl,
				success:function(data){
					console.log(data);
					var getOption ="";
					for(var k=0; k<data.data.length; k++){
						getOption+= "<option value="+data.data[k]+">"+data.data[k]+"</option>";						
					}
					console.log(getOption);
					$("#"+ele).append(getOption);
				},
				error:function(){
					console.log("Error");
					
				}
				
			});
			
		}
		populateSelectBox("http://localhost/rdppoc/apis/carType.json","carType");
		populateSelectBox("http://localhost/rdppoc/apis/fuelType.json","fuelType");
		populateSelectBox("http://localhost/rdppoc/apis/registrationState.json","registrationState");
		
		function formValidation(formObj){
			var getCount=0;
			console.log("testtest");
			formObj.find('.form-control').each(function(){
				$thisObj = $(this);
				console.log($thisObj.val());
				console.log($thisObj.parent());
				if($thisObj.val()){
					if($thisObj.hasClass("uName")){
						if($thisObj.val()==""){
							$thisObj.parent().addClass('has-error');
							getCount++;	
						}else{	
							$thisObj.parent().removeClass('has-error');
						}
					}else if($thisObj.hasClass("pNumber")){
						if($thisObj.val().length!=10){
							$thisObj.parent().addClass('has-error');
							getCount++;	
						}else{	
							$thisObj.parent().removeClass('has-error');
						}
					}else{
						$thisObj.parent().removeClass('has-error');
					}
					
					
				}else{
					$thisObj.parent().addClass('has-error');
					getCount++;					
				}
				
				
			});
			
			console.log("getCount=="+getCount);
			if(getCount>0){
					return false;
				}else{
					return true;
				}
		}
		
		function onSuccessFunc(){
			$.ajax({
				type:"post",
				dataType:"json",
				url:"http://localhost/rdppoc/apis/getQ.json",
				success:function(data){
					console.log(data);
					var getLI = "";
					for(var i=0; i<data.bank.length; i++){
						getLI += "<li id='ins_"+i+"' data-name='"+data.bank[i].name+"' data-price='"+data.bank[i].price+"' draggable='true' ondragstart='dragEle(event)'>"+data.bank[i].name+"</li>";
						
					}
					$("#banking").html(getLI);
					
				},
				error:function(){
					console.log("Error");
					
				}
				
			});
			$("#secondRow").removeClass("hide");
		}
		
		$("#registerInsurance").on("submit", function(e){
			e.preventDefault();
			var isvalid = formValidation($(this));
			console.log("isvalid+++++++++++++"+isvalid);
			if(isvalid){
				onSuccessFunc();
			}
		});
		
		$('#insuranceSubmit').on('click', function(){
			var getBankingTargetLi = $("#bankingTarget").find("li");
			if(getBankingTargetLi.length>0){
				var finalJson = {};
				var insuranceDetails = {};
				finalJson["carType"] = $("#finalJson").val();
				finalJson["fuelType"] = $("#fuelType").val();
				finalJson["registrationState"] = $("#registrationState").val();
				finalJson["userName"] = $("#userName").val();
				finalJson["phomeNumber"] = $("#phomeNumber").val();
				insuranceDetails["name"] = getBankingTargetLi.attr("data-name");
				insuranceDetails["price"] = getBankingTargetLi.attr("data-price");
				finalJson['plan'] = insuranceDetails;
				
				
				$.ajax({
					type:"post",
					dataType:"json",
					url:"http://localhost/rdppoc/apis/getQ.json",
					success:function(data){
						console.log(data);
						data.bank.policyNumber = '123456789'; // It will come from actual responce as data.data.policyNumber
                        $('#policyNumber').text(data.bank.policyNumber);
                        $("#myModal").modal();
						
					},
					error:function(){
						console.log("Error");
						
					}
					
				});
			
			}else{
				
				$('#bankingTarget').parent().addClass('error');
				
			}
			
			
			
		});	
		
	});	
});

function dragEle(e){	
	e.dataTransfer.setData("text", e.target.id);	
}

function dropEle(e){
	e.preventDefault();	
	var getdataEle = e.dataTransfer.getData("text");
	var tgtElement = e.target;  
	console.log("----tgtElement---");
	console.log(tgtElement);
	console.log(e.target.tagName);
	console.log($(tgtElement).attr('id'));
	
	if(e.target.tagName && e.target.tagName=="li"){
		tgtElement = e.target.parentElement;
	}
	
	if($(tgtElement).attr('id')=="bankingTarget" && $("#bankingTarget").find("li").length>0){
		alert("Only one insurance should be allowed")
		
	}else{
		tgtElement.appendChild(document.getElementById(getdataEle));
		
	}
}


function allowDragDrop(e){
	e.preventDefault();
	
}















