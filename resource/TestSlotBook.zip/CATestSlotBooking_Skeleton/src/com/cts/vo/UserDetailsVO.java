package com.cts.vo;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import com.sun.istack.internal.NotNull;

public class UserDetailsVO {

	@NotEmpty
	//@Pattern(regexp="^[a-zA-Z\\s]{2,30}$")
	private String userName;
	
	@NotEmpty 
	private String password;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
