package com.cts.validator;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;

import com.cts.vo.BookingSlotVO;


public class BookingValidator implements Validator {

	private HashMap<String, BookingSlotVO> bookingSlot=new LinkedHashMap<>();

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class arg0) {
		// TODO Auto-generated method stub
		return BookingSlotVO.class.equals(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.validation.Validator#validate(java.lang.Object,
	 * org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		BookingSlotVO bookingSlotVO=(BookingSlotVO) target;
		//ValidationUtils.rejectIfEmptyOrWhitespace(errors, "employeeId", "required.employeeId");
//		if(!"".equals(bookingSlotVO.getEmployeeId().trim()) && !Pattern.matches("\\d+", bookingSlotVO.getEmployeeId().trim())){
//			errors.rejectValue("employeeId", "typeMismatch.int", new Object[]{"Employee Id"}, "");
//		}else if(!"".equals(bookingSlotVO.getEmployeeId().trim())  && bookingSlotVO.getEmployeeId().length() != 6){
//			errors.rejectValue("employeeId", "invalid.employeeId");
//		}
//		if(!"".equals(bookingSlotVO.getEmployeeId().trim()) && !bookingSlotVO.getEmployeeId().matches("\\d{6}")){
//			errors.rejectValue("employeeId", "invalid.employeeId");
//		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "employeeId", "error.required", new Object[] {"Employee Id"});
//		if(bookingSlotVO.getEmployeeId() !=null && !bookingSlotVO.getEmployeeId().toString().matches("\\d{6}")){
//			errors.rejectValue("employeeId", "invalid.employeeId");
//		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "employeeName", "error.required", new Object[] {"Employee Name"});
		if(!"".equals(bookingSlotVO.getEmployeeName().trim()) && !bookingSlotVO.getEmployeeName().trim().matches("^[a-zA-Z\\s]{2,30}$")){
			errors.rejectValue("employeeName", "invalid.employeeName");
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "error.required", new Object[] {"Email"});
		if(!"".equals(bookingSlotVO.getEmail().trim()) && !bookingSlotVO.getEmail().trim().matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")){
			errors.rejectValue("email", "invalid.email");
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phone", "required.phone");
		if(!"".equals(bookingSlotVO.getPhone().trim()) && !bookingSlotVO.getPhone().trim().matches("\\d{10}")){
				errors.rejectValue("phone", "phone.format");
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "accountName", "required.accountName");

		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "assessmentName", "required.assessmentName");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "level", "required.level");
		
		if(bookingSlotVO.getDateOfAssessment() == null){
			errors.rejectValue("dateOfAssessment", "required.dateOfAssessment");
		}
		else if(new Date().after(bookingSlotVO.getDateOfAssessment())){
			errors.rejectValue("dateOfAssessment", "before.dateOfAssessment");
		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "slot", "required.slot");
	}

}