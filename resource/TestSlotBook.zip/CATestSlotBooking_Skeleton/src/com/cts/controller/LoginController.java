package com.cts.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.vo.UserDetailsVO;

@Controller
public class LoginController {
	 
	@Autowired
	HttpSession session;
	
	@Autowired
	MessageSource messagesource;
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String showLoginPage(HttpServletRequest request, Model model){
		UserDetailsVO userDetailsVO=new UserDetailsVO();
		model.addAttribute("userDetails",userDetailsVO);
		if(session.getAttribute("fromSessionTimeOut") != null){
			model.addAttribute("logutErrMsg",messagesource.getMessage("logout.error.msg", null, null));
		}
		return "login";
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String processLoginPage(@ModelAttribute("userDetails") UserDetailsVO userDetails,BindingResult result,@CookieValue(value="userName",required=false)String userName,Model model){
		if(result.hasErrors()){
			return "login";
		}
//		
//		Cookie cookie=new Cookie("name", userDetails.getUserName()); 
//		response.addCookie(cookie);
		
		model.addAttribute("userName",userName);
		return "home";
	}
}
